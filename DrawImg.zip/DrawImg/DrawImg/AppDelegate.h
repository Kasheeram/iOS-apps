//
//  AppDelegate.h
//  DrawImg
//
//  Created by Ram on 19/09/16.
//  Copyright (c) 2016 NITD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

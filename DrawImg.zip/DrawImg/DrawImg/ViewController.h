//
//  ViewController.h
//  DrawImg
//
//  Created by Ram on 19/09/16.
//  Copyright (c) 2016 NITD. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SettingsViewController.h"



@interface ViewController : UIViewController<SettingsViewControllerDelegate,UIActionSheetDelegate>
{
    CGPoint lastPoint;
    CGFloat red;
    CGFloat green;
    CGFloat blue;
    CGFloat brush;
    CGFloat opacity;
    BOOL mouseSwiped;
}

//@interface ViewController : UIViewController <SettingsViewControllerDelegate>

@property (strong, nonatomic) IBOutlet UIImageView *mainImg;

@property (strong, nonatomic) IBOutlet UIImageView *tempDrawImg;






- (IBAction)pencilPressed:(id)sender;



- (IBAction)eraserPressed:(id)sender;
- (IBAction)rest:(id)sender;


- (IBAction)setting:(id)sender;

- (IBAction)save:(id)sender;


@end

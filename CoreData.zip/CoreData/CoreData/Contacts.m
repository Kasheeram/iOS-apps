//
//  Contacts.m
//  CoreData
//
//  Created by Ram on 26/06/16.
//  Copyright (c) 2016 NITD. All rights reserved.
//

#import "Contacts.h"


@implementation Contacts

@dynamic name;
@dynamic address;
@dynamic phone;

@end

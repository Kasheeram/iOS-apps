//
//  ViewController.h
//  CoreData
//
//  Created by Ram on 26/06/16.
//  Copyright (c) 2016 NITD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UITextField *nameFld;
@property (weak, nonatomic) IBOutlet UITextField *addressFld;
@property (weak, nonatomic) IBOutlet UITextField *phoneFld;
@property (weak, nonatomic) IBOutlet UILabel *status;

- (IBAction)Save:(id)sender;
- (IBAction)Fetch:(id)sender;

@end

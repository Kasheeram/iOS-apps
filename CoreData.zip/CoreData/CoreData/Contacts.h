//
//  Contacts.h
//  CoreData
//
//  Created by Ram on 26/06/16.
//  Copyright (c) 2016 NITD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface Contacts : NSManagedObject

@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSString * address;
@property (nonatomic, retain) NSNumber * phone;

@end

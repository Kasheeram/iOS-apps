//
//  ViewController.m
//  CoreData
//
//  Created by Ram on 26/06/16.
//  Copyright (c) 2016 NITD. All rights reserved.
//

#import "ViewController.h"
#import "AppDelegate.h"


@interface ViewController ()
{
    NSManagedObjectContext *context;
}

@end

@implementation ViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [[self nameFld]setDelegate:self];
    [[self addressFld]setDelegate:self];
    [[self phoneFld]setDelegate:self];
    
    AppDelegate *appDelegate=(AppDelegate *)[[UIApplication sharedApplication]delegate];
    context=[appDelegate managedObjectContext];
    
    
    
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    return [textField resignFirstResponder];
}


- (IBAction)Save:(id)sender {
    
  
    //AppDelegate *appDelegate=(AppDelegate *)[[UIApplication sharedApplication]delegate];
    NSEntityDescription *entitydesc=[NSEntityDescription entityForName:@"Contacts" inManagedObjectContext:context];
    NSManagedObject *newcontacts=[[NSManagedObject alloc]initWithEntity:entitydesc insertIntoManagedObjectContext:context];
    
    [newcontacts setValue:self.addressFld.text forKey:@"address"];
    [newcontacts setValue:self.nameFld.text forKey:@"name"];
    //[newcontacts setValue:self.phoneFld.text  forKey:@"phone"];
    [newcontacts setValue:[NSNumber numberWithInt:[self.phoneFld.text intValue]] forKey:@"phone"];
    
    NSError *error=nil;
    [context save:&error];
    if (error) {
        self.status.text=@"Failed to insert contacts";
    }
    else
    {
        self.status.text=@"contacted is inserted";
    }
    self.addressFld.text=@"";
    self.nameFld.text=@"";
    self.phoneFld.text=@"";
    
}

- (IBAction)Fetch:(id)sender {
    
    NSEntityDescription *entitydesc=[NSEntityDescription entityForName:@"Contacts" inManagedObjectContext:context];
    NSFetchRequest *request=[[NSFetchRequest alloc]init];
    [request setEntity:entitydesc];
    
    NSPredicate *predicate=[NSPredicate predicateWithFormat:@"name=%@",self.nameFld.text];
    [request setPredicate:predicate];
    NSError *error;
    
    NSArray *matchingData=[context executeFetchRequest:request error:&error];
    
    if (matchingData.count<=0) {
        self.status.text=@"No Contacts Found";
    }
    else
    {
       //NSString *name1;
        NSString *address1;
        NSInteger *phone1 = NULL;
        // take long integer
        
        for(NSManagedObject *obj in matchingData)
        {
            address1=[obj valueForKey:@"address"];
            //phone1=(int)[obj valueForKey:@"phone"];
           phone1=[[obj valueForKey:@"phone"]integerValue];
        }
        self.addressFld.text=[NSString stringWithFormat:@"%@",address1];
        self.phoneFld.text=[NSString stringWithFormat:@"%d",phone1];
    }
    
}
@end
